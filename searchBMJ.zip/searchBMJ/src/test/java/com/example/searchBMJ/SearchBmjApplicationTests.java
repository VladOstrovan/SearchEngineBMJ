package com.example.searchBMJ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchBmjApplicationTests {

	@Test
	void contextLoads() {
	}

}
