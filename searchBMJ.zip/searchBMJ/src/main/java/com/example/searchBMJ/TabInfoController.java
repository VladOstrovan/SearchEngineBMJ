package com.example.searchBMJ;

import com.example.searchBMJ.entity.TabInfo;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

public class TabInfoController {

        private final TabInfoService service;

        public TabInfoController(TabInfoService service) {
            this.service = service;
        }

        public List<TabInfo> getAllTabInfoEntities() {
            return service.getAllEntities();
        }

        // Add other methods as needed
        @GetMapping("/getallthatstart/{arrival}/{departure}")
        public ResponseEntity<List<TabInfo>> getAddressByEmployeeId(@Param("arrival") String arrival, @Param("departure") String departure) {
            List<TabInfo> addressResponse = this.service.findAllUsersThatLeftEarlyOrArrivedLate(arrival, departure);
            return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
        }
}
