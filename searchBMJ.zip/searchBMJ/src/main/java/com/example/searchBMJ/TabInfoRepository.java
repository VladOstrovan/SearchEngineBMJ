package com.example.searchBMJ;

import com.example.searchBMJ.entity.TabInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.sql.Time;
import java.util.List;
import java.util.Optional;

public interface TabInfoRepository extends JpaRepository<TabInfo, Integer> {

    @Query(
            value = "SELECT\n" +
                    "  timeinfo.Card,\n" +
                    "  timeinfo.Person,\n" +
                    "  persons.TName,\n" +
                    "  DATE(timeinfo.TTimeBeg) AS day,\n" +
                    "  MIN(timeinfo.TTimeBeg) AS arrival,\n" +
                    "  MAX(timeinfo.TTimeEnd) AS departure,\n" +
                    "  TIMEDIFF('17:00:00', TIME(MAX(TTimeEnd))) AS late_checkout\n" +
                    "FROM\n" +
                    "  bmj_timelog.persons,\n" +
                    "  bmj_timelog.timeinfo\n" +
                    "WHERE\n" +
                    "  persons.id = timeinfo.Person\n" +
                    "  and persons.TOrd in (10, 15, 16, 90)\n" +
                    "  AND day > CAST(:arrival AS DATE)\n" +
                    "  AND day < CAST(:departure AS DATE)\n" +
                    "GROUP BY\n" +
                    "  Person,\n" +
                    "  day\n" +
                    "HAVING\n" +
                    "  TIME(arrival) > CAST('08:00:00' as TIME)\n" +
                    "  or TIME(departure) < CAST('17:00:00' as TIME)\n",
            nativeQuery = true)
    Optional<TabInfo> findAllUsersThatLeftEarlyOrArrivedLate(@Param("arrival") String arrival, @Param("departure") String departure);
}


