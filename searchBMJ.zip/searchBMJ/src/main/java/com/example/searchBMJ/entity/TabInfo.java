package com.example.searchBMJ.entity;

import jakarta.persistence.*;
import jakarta.persistence.Id;

import java.sql.Date;
import java.sql.Time;

@Entity
@Table
public class TabInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Integer Person;
    public Integer Card;

    public String TName;

    public Date TDay;

    public Time arrival;

    public Time departure;

    public Time leftearlierbyminutes;

    public TabInfo() {
    }

    public TabInfo(Integer Person, Integer Card, String TName, Date TDay, Time arrival, Time departure, Time leftearlierbyminutes) {
        this.Person = Person;
        this.Card = Card;
        this.TName = TName;
        this.TDay = TDay;
        this.arrival = arrival;
        this.departure = departure;
        this.leftearlierbyminutes = leftearlierbyminutes;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}