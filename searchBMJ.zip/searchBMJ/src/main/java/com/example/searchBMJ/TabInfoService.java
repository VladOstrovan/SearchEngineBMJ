package com.example.searchBMJ;

import com.example.searchBMJ.entity.TabInfo;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TabInfoService {
    public final TabInfoRepository repository;

    @Autowired
    public TabInfoService(TabInfoRepository repository) {
        this.repository = repository;
    }

    @Autowired
    private ModelMapper mapper;

    public List<TabInfo> getAllEntities() {
        return repository.findAll();
    }


    public List<TabInfo> findAllUsersThatLeftEarlyOrArrivedLate(String arrival, String departure) {
        Optional<TabInfo> allUserLogs = this.repository.findAllUsersThatLeftEarlyOrArrivedLate(arrival, departure);
        List<TabInfo> dt = (List<TabInfo>) mapper.map(allUserLogs, TabInfo.class);
        return dt;
    }

}
