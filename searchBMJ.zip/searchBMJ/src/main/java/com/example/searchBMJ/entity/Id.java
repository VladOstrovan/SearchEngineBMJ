package com.example.searchBMJ.entity;

public @interface Id {
}
